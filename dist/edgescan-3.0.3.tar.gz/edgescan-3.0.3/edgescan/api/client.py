import distutils.util
import gzip
import hashlib
import json
import logging
import os
import os.path
import shutil
import tempfile
import urllib.parse
from typing import Any, Dict, Iterable, Iterator, Optional

import edgescan.api.session
import edgescan.data.parser as parser
import edgescan.patterns
import edgescan.serialization
import edgescan.time
from edgescan.constants import (
    ASSETS,
    DEFAULT_API_KEY,
    DEFAULT_HOST,
    LICENSES,
    RESOURCE_TYPES,
    VIRTUAL_RESOURCE_TYPES,
)
from edgescan.data.parser import CREATE_TIME, UPDATE_TIME
from edgescan.type_hints import INTS, STRS, TIME

logger = logging.getLogger(__name__)


class Client:
    def __init__(self, host: str = DEFAULT_HOST, api_key: str = DEFAULT_API_KEY):
        self.host = host
        self.url = "https://" + host
        self.session = edgescan.api.session.get_session(api_key=api_key)

    def caching_enabled(self) -> bool:
        v = os.getenv("EDGESCAN_ENABLE_CACHE", True)
        if v is None:
            return False

        if isinstance(v, str):
            return bool(distutils.util.strtobool(v))
        return bool(v)

    def caching_disabled(self) -> bool:
        return not self.caching_enabled()

    def get_download_url(self, resource_type: str) -> str:
        """
        Get the URL to download resources of a particular type.

        :param resource_type: the type of resource to download.
        :return: the URL to download the resource.
        """
        assert resource_type in RESOURCE_TYPES
        return urllib.parse.urljoin(self.url, f"api/v1/{resource_type}.json")

    def get_object(self, resource_type: str, object_id: int) -> Optional[dict]:
        """
        Get an object by ID.

        :param resource_type: the type of object to get.
        :param object_id: the ID of the object to get.
        :return: the object, or None if it does not exist.
        """
        rows = self.iter_objects(resource_type=resource_type, ids=[object_id])
        return next(rows, None)

    def iter_objects(
        self,
        resource_type: str,
        ids: Optional[INTS] = None,
        names: Optional[STRS] = None,
        min_create_time: Optional[TIME] = None,
        max_create_time: Optional[TIME] = None,
        min_update_time: Optional[TIME] = None,
        max_update_time: Optional[TIME] = None,
    ) -> Iterator[dict]:
        """
        List objects of a given type.

        :param resource_type: the type of object to list.
        :param ids: a list of IDs to filter by.
        :param names: a list of names to filter by.
        :param min_create_time: a minimum creation time to filter by.
        :param max_create_time: a maximum creation time to filter by.
        :param min_update_time: the minimum update time to filter by.
        :param max_update_time: the maximum update time to filter by.
        :return: an iterator of objects.
        """
        logger.info(f"Listing {resource_type}")
        rows = self._iter_objects(resource_type=resource_type)
        if ids:
            rows = filter(lambda row: row["id"] in ids, rows)

        if names:
            rows = filter(
                lambda row: edgescan.patterns.matches(row["name"], names), rows
            )

        if min_create_time or max_create_time:
            rows = filter(
                lambda row: edgescan.time.in_range(
                    parser.get(row, CREATE_TIME), min_create_time, max_create_time
                ),
                rows,
            )

        if min_update_time or max_update_time:
            rows = filter(
                lambda row: edgescan.time.in_range(
                    parser.get(row, UPDATE_TIME), min_update_time, max_update_time
                ),
                rows,
            )

        yield from rows

    def _iter_objects(self, resource_type: str) -> Iterator[dict]:
        if resource_type == LICENSES:
            yield from self._iter_licenses()
        elif self.caching_enabled():
            yield from self._iter_objects_with_caching(resource_type)
        else:
            yield from self._iter_objects_without_caching(resource_type)

    def _iter_licenses(self) -> Iterator[dict]:
        seen = set()
        for asset in self.iter_objects(ASSETS):
            active_license = asset["active_licence"]
            if active_license["id"] not in seen:
                seen.add(active_license["id"])
                yield active_license

    def _iter_objects_with_caching(self, resource_type: str) -> Iterator[dict]:
        url = self.get_download_url(resource_type)
        response = self.session.head(url)

        #: Identify the latest version of the data.
        latest_version = hashlib.md5(
            response.headers["ETag"].encode("utf-8")
        ).hexdigest()
        output_path = os.path.join(
            tempfile.gettempdir(),
            "edgescan",
            resource_type,
            latest_version + ".jsonl.gz",
        )

        cache_hit = os.path.exists(output_path)
        if cache_hit:
            logger.debug("Cache hit for %s", resource_type)
            yield from self._read_from_cache(output_path)
        else:
            logger.debug("Cache miss for %s", resource_type)

            #: Remove stale data.
            output_directory = os.path.dirname(output_path)
            if os.path.isdir(output_directory):
                logger.debug("Invalidating cache for %s", resource_type)
                shutil.rmtree(output_directory)
            os.makedirs(output_directory, exist_ok=True)

            #: Download the latest data.
            rows = tuple(self._iter_objects_without_caching(resource_type))
            total = len(rows)
            if total == 0:
                logger.warning("No %s found", resource_type)
                return

            #: Write it to the cache.
            logger.debug("Writing %d %s to %s", total, resource_type, output_path)
            self._write_to_cache(rows, output_path)

            #: Return the data that's already in memory.
            yield from rows

    def _read_from_cache(self, path: str) -> Iterator[dict]:
        with gzip.open(path, "rb") as fp:
            for line in fp:
                line = line.strip()
                if line:
                    row = json.loads(line)
                    yield row

    def _write_to_cache(self, rows: Iterable[dict], path: str) -> None:
        with gzip.open(path, "w") as fp:
            for row in rows:
                if row:
                    txt = json.dumps(row) + "\n"
                    fp.write(txt.encode("utf-8"))

    def _iter_objects_without_caching(self, resource_type: str) -> Iterator[dict]:
        url = self.get_download_url(resource_type)

        response = self.session.get(url)
        response.raise_for_status()

        for row in response.json()[resource_type]:
            if row:
                yield row

    def export_objects(
        self,
        resource_type: str,
        path: str,
        json_lines: bool = True,
        json_indent: Optional[int] = edgescan.serialization.DEFAULT_JSON_INDENT,
        ids: Optional[INTS] = None,
        names: Optional[STRS] = None,
        min_create_time: Optional[TIME] = None,
        max_create_time: Optional[TIME] = None,
        min_update_time: Optional[TIME] = None,
        max_update_time: Optional[TIME] = None,
    ):
        """
        Export objects of a given type to a file.

        :param resource_type: the type of object to export.
        :param ids: a list of IDs to filter by.
        :param names: a list of names to filter by.
        :param min_create_time: a minimum creation time to filter by.
        :param max_create_time: a maximum creation time to filter by.
        :param min_update_time: the minimum update time to filter by.
        :param max_update_time: the maximum update time to filter by.
        :param path: the path to the file to export to.
        """
        logger.debug("Exporting %s to %s", resource_type, path)

        rows = tuple(
            self.iter_objects(
                resource_type=resource_type,
                ids=ids,
                names=names,
                min_create_time=min_create_time,
                max_create_time=max_create_time,
                min_update_time=min_update_time,
                max_update_time=max_update_time,
            )
        )
        total = len(rows)
        if total == 0:
            logger.warning("No %s to export to %s", resource_type, path)
        else:
            logger.debug("Exporting %d %s to %s", total, resource_type, path)

            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as file:
                if json_lines:
                    for row in rows:
                        txt = json.dumps(row) + "\n"
                        file.write(txt)
                else:
                    json.dump(rows, file, indent=json_indent)

            logger.info("Exported %d %s to %s", total, resource_type, path)

    def export_all_objects(
        self,
        output_directory: str,
        json_lines: bool = True,
        json_indent: Optional[int] = edgescan.serialization.DEFAULT_JSON_INDENT,
        min_create_time: Optional[TIME] = None,
        max_create_time: Optional[TIME] = None,
        min_update_time: Optional[TIME] = None,
        max_update_time: Optional[TIME] = None,
    ):
        """
        Export all objects to a directory.

        :param output_directory: the directory to export to.
        :param json_lines: whether to export as JSON lines.
        :param json_indent: the indentation level to use for JSON documents.
        :param min_create_time: a minimum creation time to filter by.
        :param max_create_time: a maximum creation time to filter by.
        :param min_update_time: the minimum update time to filter by.
        :param max_update_time: the maximum update time to filter by.
        """
        for resource_type in RESOURCE_TYPES:
            if json_lines:
                ext = "jsonl"
            else:
                ext = "json"

            path = os.path.join(output_directory, resource_type + f".{ext}")
            self.export_objects(
                resource_type=resource_type,
                path=path,
                json_lines=json_lines,
                json_indent=json_indent,
                min_create_time=min_create_time,
                max_create_time=max_create_time,
                min_update_time=min_update_time,
                max_update_time=max_update_time,
            )

    def count_objects(
        self,
        resource_type: str,
        ids: Optional[INTS] = None,
        names: Optional[STRS] = None,
        min_create_time: Optional[TIME] = None,
        max_create_time: Optional[TIME] = None,
        min_update_time: Optional[TIME] = None,
        max_update_time: Optional[TIME] = None,
    ) -> int:
        """
        Count the number of objects of a given type.

        :param resource_type: the type of object to count.
        :param ids: the IDs of the objects to count.
        :param names: the names of the objects to count.
        :param min_create_time: the minimum creation time of the objects to count.
        :param max_create_time: the maximum creation time of the objects to count.
        :param min_update_time: the minimum update time of the objects to count.
        :param max_update_time: the maximum update time of the objects to count.
        :return: the number of objects of the given type.
        """
        logger.info("Counting %s", resource_type)
        if resource_type in VIRTUAL_RESOURCE_TYPES or any(
            (
                ids,
                names,
                min_create_time,
                max_create_time,
                min_update_time,
                max_update_time,
            )
        ):
            rows = self.iter_objects(
                resource_type=resource_type,
                min_create_time=min_create_time,
                max_create_time=max_create_time,
                min_update_time=min_update_time,
                max_update_time=max_update_time,
            )
            total = _len(rows)
        else:
            url = self.get_download_url(resource_type)
            response = self.session.get(url)
            response.raise_for_status()

            reply = response.json()
            total = reply["total"]
        return total


def _len(it: Any) -> int:
    try:
        return len(it)
    except TypeError:
        return sum(1 for _ in it)

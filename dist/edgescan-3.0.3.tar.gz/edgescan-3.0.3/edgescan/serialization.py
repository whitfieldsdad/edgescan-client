import dataclasses
import datetime
import json
from json import JSONEncoder as _JSONEncoder
from typing import Any, Optional

DEFAULT_JSON_INDENT = 4


class JSONEncoder(_JSONEncoder):
    def default(self, obj):
        if dataclasses.is_dataclass(obj):
            return dataclasses.asdict(obj)
        if isinstance(obj, (datetime.date, datetime.datetime)):
            return obj.isoformat()
        elif isinstance(obj, datetime.timedelta):
            return obj.total_seconds()
        elif isinstance(obj, set):
            return sorted(obj)
        else:
            return super().default(obj)


def to_json(value: Any, indent: Optional[int] = DEFAULT_JSON_INDENT):
    return json.dumps(value, indent=indent, cls=JSONEncoder)


def write_json_file(
    value: Any, output_file: str, indent: Optional[int] = DEFAULT_JSON_INDENT
):
    with open(output_file, "w") as f:
        json.dump(value, f, indent=indent, cls=JSONEncoder)


def write_jsonl_file(rows: list, output_file: str):
    with open(output_file, "w") as f:
        for row in rows:
            if row:
                line = to_json(row)
                f.write(line + "\n")

# An API client for Edgescan

---

## Overview

This package provides an API client for [Edgescan](https://www.edgescan.com/)'s API.

- [Background information](#background-information)
  - [Data model](#data-model)
- [Features](#features)
- [Usage](#usage)
  - [Installation](#installation)
    - [Environment variables](#environment-variables)
    - [Command line interface](#command-line-interface)
      - [Listing and counting objects](#listing-and-counting-objects)
        - [Listing and counting assets](#listing-and-counting-assets)
        - [Listing and counting hosts](#listing-and-counting-hosts)
        - [Listing and counting vulnerabilities](#listing-and-counting-vulnerabilities)
        - [Listing and counting licenses](#listing-and-counting-licenses)
    - [Testing](#testing)
      - [Reading the code coverage report in your web browser](#reading-the-code-coverage-report-in-your-web-browser)
        - [Reading the code coverage report from the command line](#reading-the-code-coverage-report-from-the-command-line)

## Background information

[Edgescan](https://www.edgescan.com/) is a cloud-based vulnerability management and penetration testing solution that allows you to identify both network and application layer vulnerabilities across a wide variety of systems.

> ℹ️ This package is not maintained by, supported by, or in any way affiliated with Edgescan.

### Data model

![Edgescan's data model](resources/images/edgescan-data-model.png)

Edgescan's data model includes:

- **Assets**: define the scope of a scan, such as a network range in CIDR notation or a list of IP addresses;
- **Hosts**: provide information about physical or virtual machines, such as their IP address, hostname, and operating system;
- **Vulnerabilities**: are mapped to _hosts_ and provide rich context for vulnerabilities including CVSS scores and EPSS scores
- **Licenses**: licenses that apply to one or more assets

> ℹ️ Licenses are not top-level objects in Edgescan's data model. They are embedded within the `active_license` field of assets, but are automatically extracted for convenience

## Implementation

This package is implemented as a Python package that can be installed via `pip` or `poetry`.

There are a variety of different ways of using this package.

1. You can use a pre-built executable from the `dist/` folder
2. You can [build the package from source](#building-from-source) using `poetry`
3. You can [build a container image](#building-container-images) using `docker` and `make`
4. You can run a pre-built container image from a container registry


> 👷🚧 This package is not yet available on PyPI.

> 👷🚧 This package is not yet available on a publicly accessible container registry.

### Requirements

- [Python 3.8](https://www.python.org/) or later (see [pyproject.toml](pyproject.toml) for version constraints)
- [Poetry](https://github.com/python-poetry/poetry) for dependency management (optional)
- [Docker](https://www.docker.com/) for containers and container accessories (optional)
- [Make](https://www.gnu.org/software/make/) for build automation (optional)

> ℹ️ Poetry is only required if you want to install the package from source or make changes to the source code.

> ℹ️ Docker is only required if you want to build or run the container image.

> ℹ️ Make is only required if you want to make changes to the source code or container image.

### Features

You can use this package to:

- List assets, hosts, licenses, or vulnerabilities in either JSON or JSONL format
- Count assets, hosts, licenses, or vulnerabilities (while optionally grouping them based on the value of arbitrary fields)

---

## Usage

## Installation

To install from source (requires [`poetry`](https://github.com/python-poetry/poetry)):

```shell
make install
```

## Environment variables

| Name                    | Description                                    | Default           | Required |
|-------------------------|------------------------------------------------|-------------------|----------|
| `EDGESCAN_HOST`         | Address of Edgescan API                        | live.edgescan.com | false    |
| `EDGESCAN_API_KEY`      | Edgescan API key                               | n/a               | true     |
| `EDGESCAN_ENABLE_CACHE` | Enable/disable caching to temporary directory. | n/a               | false    |
| `CONTAINER_IMAGE`       | Name of the container image                    | edgescan-api-client | false    |
| `CONTAINER_REGISTRY`    | Container registry to which the container image will be released | localhost:5000 | false    |

### Command line interface

The command line interface can be used to list or count objects.

#### Listing and counting objects

You can list assets, hosts, vulnerabilities, licenses, or services via the command line interface.

> ℹ️ You can use the `--help` flag to view the available options for each command

##### Listing and counting assets

You can list assets like this:

```shell
poetry run edgescan list assets | jq
```

And you can count assets like this:

```shell
poetry run edgescan count assets
```

You can also tally assets based on the value of arbitrary fields!

For example:

```shell
poetry run edgescan count assets --group-by "onboarding_status" | jq
```

```json
{
  "onboarded": 1,
  "staged": 2
}
```

Or:

```shell
poetry run edgescan count assets --group-by "targeting_mode" | jq
```

```json
{
  "automatic": 3,
}
```

##### Listing and counting hosts

To list hosts:

```shell
poetry run edgescan list hosts | jq
```

To count hosts:

```shell
poetry run edgescan count hosts
```

To count hosts by OS type:

```shell

```

##### Listing and counting vulnerabilities

You can list vulnerabilities like this:

```shell
poetry run edgescan list vulnerabilities | jq
```

And count vulnerabilities like this:

```shell
poetry run edgescan count vulnerabilities
```

##### Listing and counting licenses

You can list licenses like this:

```shell
poetry run edgescan list licenses | jq
```

And count licenses like this:

```shell
poetry run edgescan count licenses
```

> ℹ️ Licenses are extracted from assets and are not a first-class object in Edgescan's API.

### Testing

To run the tests and measure code coverage:

```shell
make test
```

This will generate the following reports:

- [HTML-formatted code coverage report](coverage/html/index.html): `coverage/html/index.html`
- [JSON-formatted code coverage report](coverage/json/coverage.json): `coverage/json/coverage.json`

#### Reading the code coverage report in your web browser

To read the HTML-formatted code coverage report in your default web browser, execute one of the following commands (depending on your operating system):

**On Windows**:

```shell
start coverage/html/index.html
```

**On macOS**:

```shell
open coverage/html/index.html
```

**On Linux**:

```shell
xdg-open coverage/html/index.html
```

#### Reading the code coverage report from the command line

To read the JSON-formatted code coverage report from the command line, execute the following command:

```shell
poetry run coverage report -m
```

```shell
Name                                        Stmts   Miss  Cover   Missing
-------------------------------------------------------------------------
edgescan/__init__.py                            2      0   100%
edgescan/api/__init__.py                        0      0   100%
edgescan/api/client.py                        146     16    89%   36, 39, 43, 93, 96, 99, 109, 145-146, 217, 252-259
edgescan/api/session.py                        52      4    92%   29, 87-89
edgescan/cli.py                                99     13    87%   89-92, 124-138, 201-202, 214
edgescan/constants.py                          15      0   100%
edgescan/data/__init__.py                       0      0   100%
edgescan/data/parser.py                        52      7    87%   23-29, 75
edgescan/data/types/__init__.py                 6      0   100%
edgescan/data/types/assessment.py              26     11    58%   19, 30-45, 48
edgescan/data/types/asset.py                   41      3    93%   40, 44, 48
edgescan/data/types/base.py                    18      7    61%   13, 17, 24-31
edgescan/data/types/host.py                    44     11    75%   27-30, 34, 38, 42, 46, 50, 53, 56
edgescan/data/types/license.py                 19      2    89%   21, 24
edgescan/data/types/location_specifier.py      14      3    79%   14, 17, 20
edgescan/data/types/vulnerability.py           76     28    63%   43, 47, 51, 55, 58, 61, 64, 85-118, 121
edgescan/errors.py                              4      0   100%
edgescan/patterns.py                           15     10    33%   7-14, 18-20
edgescan/platforms.py                          40     19    52%   21, 25, 29, 33, 37, 41, 45-67
edgescan/serialization.py                      28     16    43%   13-22, 30-31, 35-39
edgescan/tallies.py                            27     21    22%   8-30, 34, 38
edgescan/time.py                               29     15    48%   11-17, 30, 33-40
edgescan/type_hints.py                         10      0   100%
edgescan/types.py                              18      8    56%   9-11, 19-24
tests/__init__.py                               0      0   100%
tests/client.py                                 2      0   100%
tests/integration/__init__.py                   0      0   100%
tests/integration/test_lookup_objects.py       29      2    93%   18, 33
tests/integration/test_parsers.py              21      1    95%   27
tests/runner.py                                 9      1    89%   10
tests/test_cli.py                              26      1    96%   21
-------------------------------------------------------------------------
TOTAL                                         868    199    77%
```

### Docker

This repository includes a [`Dockerfile`](Dockerfile) that you can use to build a container image providing the API client.

The image is based on [`python:3.9-slim-buster`](https://hub.docker.com/_/python) and invokes the command line interface for the Edgescan API client.

#### Building container images

To build a container image:

```shell
make container
```

#### Running containers

To run a container:

```shell
docker run whitfieldsdad/edgescan-api-client:latest --help
```

```text
Usage: python -m edgescan.cli [OPTIONS] COMMAND [ARGS]...

  Lookup or count objects via Edgescan's API.

Options:
  --json-lines
  --json-indent INTEGER  [default: 4]
  --help                 Show this message and exit.

Commands:
  count       Count assets.
  export      Export objects to a file in JSON or JSONL format.
  export-all  Export all objects to a file in JSONL format.
  get         Lookup assets.
  list        List objects.
```

From here, you can use the API client as you would from the command line.

For example, to export information about all assets, hosts, vulnerabilities, and licenses to a directory named `private` in JSON format:

```shell
docker run -e EDGESCAN_API_KEY=$EDGESCAN_API_KEY whitfieldsdad/edgescan-api-client:latest export-all private/
```

Yielding:

```shell
ls private/
```

```text
assets.json             hosts.json              licenses.json           services.json           vulnerabilities.json
```

## Releasing

"Releasing" refers to the process of publishing a new version of the API client or container image.

### Releasing a new version of the API client

To release a new version of the API client:

1. Update the version number in [`pyproject.toml`](pyproject.toml)
2. Update the version number in [`setup.py`](setup.py)
3. Commit the changes.
4. Tag the commit with the version number.
5. Push the commit and tag.

#### Example release workflow

For example, to release version `0.1.0`:

1. Set the `version` in [`pyproject.toml`](pyproject.toml) to `0.1.0`.
2. Set the `version` in [`setup.py`](setup.py) to `0.1.0`.
3. Commit the changes.

```shell
git add
git commit -m "Bump version to 0.1.0"
```

4. Tag the commit with the version number.

```shell
git tag 0.1.0
```

5. Push the commit and tag.

```shell
git push
git push --tags
```

After updating the version number in [`pyproject.toml`](pyproject.toml) and [`Dockerfile`](Dockerfile):

```shell
git commit -m "Bump version to 0.1.0"
git tag 0.1.0
git push
git push --tags
```

### Releasing a new version of the container image

The release process for the container image is the same as the release process for the API client and is automated using the `container` and `release-container` [Makefile](Makefile) targets.

#### Example container release workflow

The following command will:

- Build a container image
- Tag the container image with the appropriate version number
- Push the container image to a Docker registry

```shell
make container && make release-container
```

> ℹ️ Containers are automatically tagged with the version number in [`pyproject.toml`](pyproject.toml).

> ℹ️ Licenses are extracted from assets and are not a first-class object in Edgescan's API.

## Contributing

Feel free to open a pull request or issue if you find a bug or have a feature request.

## License

This project is licensed under the [MIT License](LICENSE.md).

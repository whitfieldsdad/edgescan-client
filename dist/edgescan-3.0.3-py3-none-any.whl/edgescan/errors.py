class _CredentialError(ValueError):
    pass


class MissingCredentialsError(_CredentialError):
    pass

from edgescan.api.client import Client
from edgescan.data.types import (
    Assessment,
    Asset,
    Host,
    License,
    LocationSpecifier,
    Vulnerability,
)

import datetime
import itertools
import json
import logging
from typing import List, Optional

import click

import edgescan.serialization
import edgescan.tallies
import edgescan.time
from edgescan.api.client import Client
from edgescan.constants import RESOURCE_TYPES

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

JSON = "json"
JSONL = "jsonl"

OUTPUT_FORMATS = (JSON, JSONL)


@click.group()
@click.option("--json-lines", is_flag=True, default=False, show_default=True)
@click.option(
    "--json-indent",
    type=int,
    default=edgescan.serialization.DEFAULT_JSON_INDENT,
    show_default=True,
)
@click.pass_context
def cli(ctx: click.Context, json_lines: bool, json_indent: int):
    """
    Lookup or count objects via Edgescan's API.
    """
    ctx.ensure_object(dict)
    ctx.obj = {
        "json_lines": json_lines,
        "json_indent": json_indent,
    }


@cli.command("get")
@click.argument("resource-type", type=click.Choice(RESOURCE_TYPES), required=True)
@click.argument("object-id", type=int, required=True)
@click.pass_context
def get_object(ctx: click.Context, resource_type: int, object_id: int):
    """
    Lookup assets.
    """
    api = Client()
    row = api.get_object(resource_type=resource_type, object_id=object_id)
    if row:
        txt = edgescan.serialization.to_json(row, indent=ctx.obj["json_indent"])
        click.echo(txt)


@cli.command("list")
@click.argument("resource-type", type=click.Choice(RESOURCE_TYPES), required=True)
@click.option("--id", "ids", multiple=True)
@click.option("--name", "names", multiple=True)
@click.option("--min-create-time", type=edgescan.time.to_datetime)
@click.option("--max-create-time", type=edgescan.time.to_datetime)
@click.option("--min-update-time", type=edgescan.time.to_datetime)
@click.option("--max-update-time", type=edgescan.time.to_datetime)
@click.option("--limit", type=int)
@click.pass_context
def get_objects(
    ctx: click.Context,
    resource_type: int,
    ids: List[str],
    names: List[str],
    min_create_time: Optional[datetime.datetime],
    max_create_time: Optional[datetime.datetime],
    min_update_time: Optional[datetime.datetime],
    max_update_time: Optional[datetime.datetime],
    limit: Optional[int] = None,
):
    """
    List objects.
    """
    api = Client()
    rows = api.iter_objects(
        resource_type=resource_type,
        ids=ids,
        names=names,
        min_create_time=min_create_time,
        max_create_time=max_create_time,
        min_update_time=min_update_time,
        max_update_time=max_update_time,
    )
    rows = itertools.islice(rows, limit)
    if ctx.obj["json_lines"]:
        for row in rows:
            if row:
                txt = edgescan.serialization.to_json(row)
                click.echo(txt)
    else:
        rows = list(rows)
        txt = edgescan.serialization.to_json(rows, indent=ctx.obj["json_indent"])
        click.echo(txt)


@cli.command("count")
@click.argument("resource-type", type=click.Choice(RESOURCE_TYPES), required=True)
@click.option("--id", "ids", multiple=True)
@click.option("--name", "names", multiple=True)
@click.option("--min-create-time", type=edgescan.time.to_datetime)
@click.option("--max-create-time", type=edgescan.time.to_datetime)
@click.option("--min-update-time", type=edgescan.time.to_datetime)
@click.option("--max-update-time", type=edgescan.time.to_datetime)
@click.option("--group-by")
@click.option("--sort-by-key/--sort-by-value", default=True)
def count_objects(
    resource_type: str,
    ids: List[str],
    names: List[str],
    min_create_time: Optional[datetime.datetime],
    max_create_time: Optional[datetime.datetime],
    min_update_time: Optional[datetime.datetime],
    max_update_time: Optional[datetime.datetime],
    group_by: Optional[str],
    sort_by_key: bool,
):
    """
    Count assets.
    """
    api = Client()
    if group_by:
        rows = api.iter_objects(
            resource_type=resource_type,
            ids=ids,
            names=names,
            min_create_time=min_create_time,
            max_create_time=max_create_time,
            min_update_time=min_update_time,
            max_update_time=max_update_time,
        )
        tally = edgescan.tallies.tally_by(rows, group_by)
        if sort_by_key:
            tally = edgescan.tallies.sort_by_key(tally)
        else:
            tally = edgescan.tallies.sort_by_value(tally)
        result = edgescan.serialization.to_json(tally)
    else:
        result = api.count_objects(
            resource_type=resource_type,
            ids=ids,
            names=names,
            min_create_time=min_create_time,
            max_create_time=max_create_time,
            min_update_time=min_update_time,
            max_update_time=max_update_time,
        )
    print(result)


@cli.command("export")
@click.argument("resource-type", type=click.Choice(RESOURCE_TYPES), required=True)
@click.argument("path", required=True)
@click.option("--min-create-time", type=edgescan.time.to_datetime)
@click.option("--max-create-time", type=edgescan.time.to_datetime)
@click.option("--min-update-time", type=edgescan.time.to_datetime)
@click.option("--max-update-time", type=edgescan.time.to_datetime)
@click.pass_context
def export_objects(
    ctx: click.Context,
    resource_type: Optional[str],
    path: str,
    min_create_time: Optional[datetime.datetime],
    max_create_time: Optional[datetime.datetime],
    min_update_time: Optional[datetime.datetime],
    max_update_time: Optional[datetime.datetime],
):
    """
    Export objects to a file in JSON or JSONL format.
    """
    api = Client()
    api.export_objects(
        resource_type=resource_type,
        path=path,
        min_create_time=min_create_time,
        max_create_time=max_create_time,
        min_update_time=min_update_time,
        max_update_time=max_update_time,
        json_indent=ctx.obj["json_indent"],
        json_lines=ctx.obj["json_lines"],
    )


@cli.command("export-all")
@click.argument("output-directory", required=True)
@click.option("--min-create-time", type=edgescan.time.to_datetime)
@click.option("--max-create-time", type=edgescan.time.to_datetime)
@click.option("--min-update-time", type=edgescan.time.to_datetime)
@click.option("--max-update-time", type=edgescan.time.to_datetime)
@click.pass_context
def export_all_objects(
    ctx: click.Context,
    output_directory: str,
    min_create_time: Optional[datetime.datetime],
    max_create_time: Optional[datetime.datetime],
    min_update_time: Optional[datetime.datetime],
    max_update_time: Optional[datetime.datetime],
):
    """
    Export all objects to a file in JSONL format.
    """
    api = Client()
    api.export_all_objects(
        output_directory=output_directory,
        min_create_time=min_create_time,
        max_create_time=max_create_time,
        min_update_time=min_update_time,
        max_update_time=max_update_time,
        json_indent=ctx.obj["json_indent"],
        json_lines=ctx.obj["json_lines"],
    )


if __name__ == "__main__":
    cli()
